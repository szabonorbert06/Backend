<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreTypeRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'group_id'  => ['required', 'integer', 'exists:groups,id'],
            'name'      => ['required', 'string', 'max:50'],
            'speed'     => ['required', 'integer', 'min:1', 'max:70'],
            'height'    => ['required', 'integer'],
            'weight'    => ['required', 'integer', 'min:1', 'max:100'],
            'origin'    => ['required', 'string', 'max:255'],
            'lifetime'  => ['required', 'integer', 'min:1', 'max:25'],
            'colors'    => ['required', 'string', 'max:255'],
        ];
    }

    protected function failedValidation(Validator $validator): void
    {
        throw new HttpResponseException(
            response()->json([
                'message' => 'Validation error',
                'errors'  => $validator->errors(),
            ], 422)
        );
    }
}
