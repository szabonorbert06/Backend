<?php

namespace App\Http\Controllers;

use App\Models\Type;
use App\Http\Requests\StoreTypeRequest;
use Illuminate\Http\JsonResponse;

class TypeController extends Controller
{
    /**
     * GET /api/types
     * Returns all dog breed types with their data.
     */
    public function index(): JsonResponse
    {
        $types = Type::with('group')->get();

        return response()->json($types);
    }

    /**
     * GET /api/types/{id}
     * Returns a single dog breed type by ID.
     */
    public function show(int $id): JsonResponse
    {
        $type = Type::with('group')->find($id);

        if (!$type) {
            return response()->json([
                'message' => 'Type not found',
            ], 404);
        }

        return response()->json($type);
    }

    /**
     * POST /api/types
     * Creates a new dog breed type record.
     */
    public function store(StoreTypeRequest $request): JsonResponse
    {
        $type = Type::create($request->validated());

        return response()->json($type->load('group'), 201);
    }
}
