<?php

namespace App\Http\Controllers;

use App\Models\Group;
use Illuminate\Http\JsonResponse;

class GroupController extends Controller
{
    /**
     * GET /api/groups
     * Returns all groups with their data.
     */
    public function index(): JsonResponse
    {
        $groups = Group::all();

        return response()->json($groups);
    }
}
