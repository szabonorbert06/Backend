<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Group extends Model
{
    protected $fillable = ['name', 'visible'];

    protected $casts = [
        'visible' => 'boolean',
    ];

    public function types(): HasMany
    {
        return $this->hasMany(Type::class);
    }
}
