<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Type extends Model
{
    protected $fillable = [
        'group_id',
        'name',
        'speed',
        'height',
        'weight',
        'origin',
        'lifetime',
        'colors',
    ];

    public function group(): BelongsTo
    {
        return $this->belongsTo(Group::class);
    }
}
