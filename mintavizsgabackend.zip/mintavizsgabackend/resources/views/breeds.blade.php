<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dog Breed Guide</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
            background: #f5f5f5;
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #555;
            padding-bottom: 10px;
        }
        ul {
            list-style-type: disc;
            padding-left: 20px;
        }
        ul ul {
            list-style-type: circle;
            margin-top: 4px;
        }
        li {
            margin: 6px 0;
            font-size: 1rem;
        }
        .group-name {
            font-weight: bold;
            color: #222;
        }
        .type-name {
            color: #444;
        }
    </style>
</head>
<body>
    <h1>Kutya Fajtamutató</h1>

    @php
        use App\Models\Group;
        $groups = Group::where('visible', true)->with('types')->get();
    @endphp

    <ul>
        @foreach ($groups as $group)
            <li>
                <span class="group-name">{{ $group->name }}</span>
                @if ($group->types->isNotEmpty())
                    <ul>
                        @foreach ($group->types as $type)
                            <li class="type-name">{{ $type->name }}</li>
                        @endforeach
                    </ul>
                @endif
            </li>
        @endforeach
    </ul>
</body>
</html>
