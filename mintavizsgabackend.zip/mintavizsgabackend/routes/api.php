<?php

use App\Http\Controllers\GroupController;
use App\Http\Controllers\TypeController;
use Illuminate\Support\Facades\Route;

Route::get('/groups', [GroupController::class, 'index']);

Route::get('/types', [TypeController::class, 'index']);
Route::get('/types/{id}', [TypeController::class, 'show']);
Route::post('/types', [TypeController::class, 'store']);
